<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\ProgrammingLanguage;
use App\Models\OpenClass;
use App\Models\Thematic;
use App\Http\Requests;
use App\Models\Slider;
use Session;
use DB;
session_start();

class ClassController extends Controller
{
     public function AuthLogin(){
        if(Session::get('login_normal')){
         $admin_id = Session::get('admin_id'); 
        }
      
        if($admin_id){
            return Redirect::to('dashboard');
        }else{
            return Redirect::to('admin')->send();
        }
    }
     public function add_class(){
        $this->AuthLogin();
    	$thematic = DB::table('tbl_thematic')->orderby('thematic_id','desc')->get();
        $language = DB::table('tbl_programminglanguage')->orderby('language_id','desc')->get();
        return view('admin.class.add_class')->with(compact('thematic','language'));
    }
    public function all_class(){
        $this->AuthLogin();
    	$all_class=DB::table('tbl_class')->join('tbl_thematic','tbl_thematic.thematic_id','=','tbl_class.thematic_id')->join('tbl_programminglanguage','tbl_programminglanguage.language_id','=','tbl_class.language_id')->orderby('tbl_class.class_id')->get();
        $manager_class = view('admin.class.all_class')->with('all_class',$all_class);
        return view('admin_layout')->with('admin.class.all_class', $manager_class);
    }
     public function save_class(Request $Request){
        $this->AuthLogin();
        $data=array();    
        $data['class_name'] = $Request->class_name;
        $data['opending_day'] = $Request->opending_day;
        $data['schedule_day'] = $Request->schedule_day;
        $data['study_time'] = $Request->study_time;
        $data['tuition'] = $Request->tuition;       
        $data['address_class'] = $Request->address_class;
        $data['class_desc'] = $Request->class_desc;
        $data['class_keywords'] = $Request->class_keywords;
        $data['student_number'] = $Request->student_number;
        $data['teacher'] = $Request->teacher;
        $data['thematic_id'] = $Request->class_thematic;
        $data['language_id'] = $Request->class_language;
        $data['class_status'] = $Request->class_status;
        $data['class_image']=$Request->class_image;
        $get_image=$Request->file('class_image');
        if($get_image)
        {
            $get_name_image=$get_image->getClientOriginalName();
            $name_image=current(explode('.',$get_name_image));
            $new_image=$name_image.rand(0,99).'.'.$get_image->getClientOriginalExtension();
            $get_image->move('public/uploads/product',$new_image);
            $data['class_image']=$new_image;
            DB::table('tbl_class')->INSERT($data);
            Session::put('message',"Thêm lớp học thành công");
            return Redirect::to('add_class');
        }else
        {
            $data['class_image']='';
            DB::table('tbl_class')->INSERT($data);
            Session::put('message',"Thêm lớp học thành công");
            return Redirect::to('add_class');
        }
     }
       public function unactive_class($class_id){
        $this->AuthLogin();
    	DB::table('tbl_class')->where('class_id',$class_id)->update(['class_status'=>1]);
    	Session::put('message','Kích hoạt hiện thành công');
    	return Redirect::to('all_class');
    }
    public function active_class($class_id){
        $this->AuthLogin();
    	DB::table('tbl_class')->where('class_id',$class_id)->update(['class_status'=>0]);
    	Session::put('message','Kích hoạt ẩn thành công');
    	return Redirect::to('all_class');
    }
    public function edit_class($class_id){
        $this->AuthLogin();
        $thematic = DB::table('tbl_thematic')->orderby('thematic_id','desc')->get();
        $language = DB::table('tbl_programminglanguage')->orderby('language_id','desc')->get();
        $edit_class = DB::table('tbl_class')->where('class_id',$class_id)->get();
        $manager_class = view('admin.class.edit_class')->with('edit_class',$edit_class)->with('thematic',$thematic)
        ->with('language',$language);
        return view('admin_layout')->with('admin.class.edit_class',$manager_class);
    }
    public function update_class(Request $Request, $class_id){
        $this->AuthLogin();
        $data=array();
        $data['class_name'] = $Request->class_name;
        $data['opending_day'] = $Request->opending_day;
        $data['schedule_day'] = $Request->schedule_day;
        $data['study_time'] = $Request->study_time;
        $data['tuition'] = $Request->tuition;       
        $data['address_class'] = $Request->address_class;
        $data['class_desc'] = $Request->class_desc;
        $data['class_keywords'] = $Request->class_keywords;
        $data['student_number'] = $Request->student_number;
        $data['teacher'] = $Request->teacher;
        $data['thematic_id'] = $Request->thematic_name;
        $data['language_id'] = $Request->language_name;

        $get_image=$Request->file('class_image');
        if($get_image)
        {
            $get_name_image=$get_image->getClientOriginalName();
            $name_image=current(explode('.',$get_name_image));
            $new_image=$name_image.rand(0,99).'.'.$get_image->getClientOriginalExtension();
            $get_image->move('public/uploads/product',$new_image);
            $data['class_image']=$new_image;
            DB::table('tbl_class')->where('class_id',$class_id)->update($data);
            Session::put('message',"Cập nhật lớp học thành công");
            return Redirect::to('all_class');
        }
        DB::table('tbl_class')->where('class_id',$class_id)->update($data);
        Session::put('message',"Cập nhập lớp học thành công");
        return Redirect::to('all_class');
    }
    public function delete_class($class_id){
        $this->AuthLogin();
    	DB::table('tbl_class')->where('class_id',$class_id)->delete();
    	Session::put('message','Xóa thành công lớp học');
    	
    	return Redirect::to('all_class');
    }
    public function view_class_details($class_id){
        $this->AuthLogin();
        $order_detail = OpenClass::where('class_id',$class_id)->get();
        return view('admin.class.view_class_details')->with(compact('order_detail'));
    }
    //home
    public function details_class($class_id){
        $slider= Slider::orderby('slider_id','DESC')->where('slider_status','1')->take(4)->get();
        $thematic = DB::table('tbl_thematic')->where('thematic_status','1')->orderby('thematic_id','desc')->get();
        $language = DB::table('tbl_programminglanguage')->where('language_status','1')->orderby('language_id','desc')->get();
        $detail_class = DB::table('tbl_class')->join('tbl_thematic','tbl_thematic.thematic_id','=','tbl_class.thematic_id')->join('tbl_programminglanguage','tbl_programminglanguage.language_id','=','tbl_class.language_id')->where('tbl_class.class_id',$class_id)->get();
        foreach($detail_class as $key => $val_class){
            $thematic_id = $val_class->thematic_id;
        }

        $related_class = DB::table('tbl_class')
       ->join('tbl_thematic','tbl_thematic.thematic_id','=','tbl_class.thematic_id')
       ->join('tbl_programminglanguage','tbl_programminglanguage.language_id','=','tbl_class.language_id')
       ->where('tbl_thematic.thematic_id',$thematic_id)
       ->WhereNotIn('tbl_class.class_id',[$class_id])->get();
    
        return view('pages.class.details_class')->with(compact('thematic','language','detail_class','related_class','slider'));
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Slider;
use DB;
class ContactController extends Controller
{
    public function contact(){
    	$thematic = DB::table('tbl_thematic')->where('thematic_status','1')->orderby('thematic_id')->get();
    	$language = DB::table('tbl_programminglanguage')->where('language_status','1')->orderby('language_id')->get();
    	 $slider= Slider::orderby('slider_id','DESC')->where('slider_status','1')->take(4)->get();
    	return view('pages.contact.contact')->with(compact('slider','thematic','language'));
    }
}

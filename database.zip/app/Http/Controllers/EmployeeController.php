<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Position;
use App\Models\Employee;
use DB;
use Session;

class EmployeeController extends Controller
{
	  public function AuthLogin(){
        if(Session::get('login_normal')){
         $admin_id = Session::get('admin_id'); 
        }
      
        if($admin_id){
            return Redirect::to('dashboard');
        }else{
            return Redirect::to('admin')->send();
        }
    }
    public function all_employee(){
    	  $this->AuthLogin();
        $all_employee = DB::table('tbl_employee')->join('tbl_position','tbl_position.position_id','=','tbl_employee.ChucVu')->get();
        $manager_employee = view('admin.employee.all_employee')->with('all_employee',$all_employee);
        return view('admin_layout')->with('admin.employee.all_employee', $manager_employee);
    }
    public function add_employee(){
    	$this->AuthLogin();
    	$position = DB::table('tbl_position')->orderby('position_id','desc')->get();
    	return view('admin.employee.add_employee')->with(compact('position'));
    }
    public function save_employee(Request $Request){
        $this->AuthLogin();
        $data=array();    
        $data['MaNhanVien'] = $Request->MaNhanVien;
        $data['TenNhanVien'] = $Request->TenNhanVien;
        $data['NgaySinh'] = $Request->NgaySinh;
        $data['SDT'] = $Request->SDT;
        $data['Email'] = $Request->Email;       
        $data['DiaChi'] = $Request->DiaChi;
        $data['TrinhDo'] = $Request->TrinhDo;
        $data['ChucVu'] = $Request->ChucVu;
        $data['HinhAnh']=$Request->HinhAnh;
        $get_image=$Request->file('HinhAnh');
        if($get_image)
        {
            $get_name_image=$get_image->getClientOriginalName();
            $name_image=current(explode('.',$get_name_image));
            $new_image=$name_image.rand(0,99).'.'.$get_image->getClientOriginalExtension();
             $get_image->move('public/uploads/product',$new_image);
            $data['HinhAnh']=$new_image;
            DB::table('tbl_employee')->INSERT($data);
            return Redirect::to('all_employee');
        }else
        {
            $data['HinhAnh']='';
            DB::table('tbl_employee')->INSERT($data);
            return Redirect::to('all_employee');
        }
     }
}

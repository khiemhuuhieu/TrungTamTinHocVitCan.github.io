<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use App\Models\Students;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\OpenClass;
use DB;
use App\Exports\ExcelExport;
use App\Imports\ExcelImport;
use Excel;
use Session;
class StudentController extends Controller
{
	  public function AuthLogin(){
        if(Session::get('login_normal')){
         $admin_id = Session::get('admin_id'); 
        }
      
        if($admin_id){
            return Redirect::to('dashboard');
        }else{
            return Redirect::to('admin')->send();
        }
    }
	public function all_student(){
		 $this->AuthLogin();

        $all_student = DB::table('tbl_students')->join('tbl_class','tbl_class.class_id','=','tbl_students.lop')->orderby('tbl_students.id','DESC')->get();
        $manager_student = view('admin.student.all_student')->with('all_student',$all_student);
        return view('admin_layout')->with('admin.student.all_student', $manager_student);
	}
	public function add_student(){
        $class = DB::table('tbl_class')->orderby('class_id','desc')->get();
		return view('admin.student.add_student')->with(compact('class'));
	}
     public function save_students(Request $Request){
        $this->AuthLogin();
        $data = $Request->all();

        $students = new Students();

        $students->MaHocVien = $data['ma_hocvien'];
        $students->TenHocVien = $data['ten_hocvien'];
        $students->NgaySinh = $data['ngay_sinh'];
        $students->Lop = $data['lop'];
        $students->Diachi = $data['dia_chi'];
        $students->GhiChu = $data['ghi_chu'];
        $students->TinhTrang = $data['tinh_trang'];
        $students->SDT = $data['so_dienthoai'];
        $students->MaPH = $data['ma_phuhuynh'];
        $students->save();

        Session::put('message',"Thêm học viên thành công");
        return Redirect::to('all_student');
    }
    public function edit_student($id){
        $this->AuthLogin();

        $class = DB::table('tbl_class')->orderby('class_id','desc')->get();
        $edit_student = DB::table('tbl_students')->where('id',$id)->get();
        $manager_student = view('admin.student.edit_student')->with('edit_student',$edit_student)->with('class',$class);
        return view('admin_layout')->with('admin.student.edit_student',$manager_student);
    }
    public function save_edit_students(Request $Request, $id){
        $this->AuthLogin();

        $data = $Request->all();
        $student = Students::find($id);
        $student->MaHocVien = $data['ma_hocvien'];
        $student->TenHocVien = $data['ten_hocvien'];
        $student->NgaySinh = $data['ngay_sinh'];
        $student->Lop = $data['lop'];
        $student->Diachi = $data['dia_chi'];
        $student->GhiChu = $data['ghi_chu'];
        $student->TinhTrang = $data['tinh_trang'];
        $student->SDT = $data['so_dienthoai'];
        $student->MaPH = $data['ma_phuhuynh'];
        $student->save();
        return Redirect::to('all_student');

    }
    public function delete_students($id){
        $this->AuthLogin();
        DB::table('tbl_students')->where('id',$id)->delete();
        return Redirect::to('all_student');
    }
     public function export_csv(){
        return Excel::download(new ExcelExport , 'danh_sach_hoc_vien.xlsx');
    }

    public function import_csv(Request $request){
        $path = $request->file('file')->getRealPath();
        Excel::import(new ExcelImport, $path);
        return back();
    }

}
